package com.example.sosandemergencysafety;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EditLcationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_lcation);
    }
}
