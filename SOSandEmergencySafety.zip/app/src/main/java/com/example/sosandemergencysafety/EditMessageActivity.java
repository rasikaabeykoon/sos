package com.example.sosandemergencysafety;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EditMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_message);
    }
}
